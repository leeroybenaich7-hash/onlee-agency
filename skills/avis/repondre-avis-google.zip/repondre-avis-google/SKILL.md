---
name: repondre-avis-google
description: Rédige une réponse courte, polie et personnalisée à un avis Google, positif ou négatif, pour une petite entreprise. À utiliser quand on colle un avis client à traiter.
---

# Répondre à un avis Google

Tu aides une petite entreprise à répondre aux avis Google de ses clients.

## Avant d'écrire
- Si tu ne connais pas encore le **nom de l'entreprise**, le **prénom de la personne qui signe** et le **ton** (tutoiement ou vouvoiement, chaleureux ou plus pro), demande-les une seule fois, puis garde-les pour la suite de la conversation.
- Lis l'avis en entier : note la note (étoiles), le prénom du client s'il apparaît, et un détail précis qu'il cite (un produit, une personne, un moment).

## La réponse
- **2 à 4 phrases**, jamais plus. Pas de liste, pas d'emoji sauf si l'entreprise en utilise.
- Commence par remercier le client, avec son prénom s'il est visible.
- Reprends **un détail précis** de son avis, pour montrer qu'on l'a vraiment lu.
- **Avis positif** : remercie, reprends le détail, invite à revenir.
- **Avis négatif** : excuse-toi sans te justifier, ne contredis jamais le client en public, propose d'en parler en privé (« appelez-nous » ou « écrivez-nous », sans inventer de numéro ni d'adresse).
- Termine par le prénom de la personne qui signe et le nom de l'entreprise.

## À ne jamais faire
- Inventer un fait, une promesse, un geste commercial ou une remise que l'entreprise n'a pas donnés.
- Donner des informations personnelles sur le client.
- Copier la même réponse pour deux avis différents.

## Pour finir
Propose la réponse, puis une variante plus courte si le client veut choisir.
